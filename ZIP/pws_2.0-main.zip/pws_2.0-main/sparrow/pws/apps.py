from django.apps import AppConfig


class PwsConfig(AppConfig):
    name = 'pws'

# Development branch

Phase-1 changes should be committed into the Development branch only. 

# Main branch

Main branch will be used to create a stable version that will be uploaded on live. 

from django.apps import AppConfig


class qualityappConfig(AppConfig):
    name = 'qualityapp'

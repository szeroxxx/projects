# Running the app

`npm start`

# Server URL

Default server BASE URL is localhost:8000 in axios.js

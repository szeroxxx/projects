Mousetrap.bind('shift+s', function() { 
	$('[name="searchbox"]').focus();
});
<script type="text/javascript" src="jqColorPicker.min.js">
<script type="text/javascript">
    $('.color').colorPicker(); // that's it
</script>
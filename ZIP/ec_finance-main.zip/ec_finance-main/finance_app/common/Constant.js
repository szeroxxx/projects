class Constant {
  static APP_LIST_HTTP_HANDLER = "Get";
  static LIST_PAGE_SIZE = 2;
  static POST_FK_FIELD_RULE = ".";
  static appUrl="http://192.168.1.135:3000/"
}
export default Constant;
